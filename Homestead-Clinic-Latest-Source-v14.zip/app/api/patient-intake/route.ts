import {db} from "@/lib/clinic-db";
import {contactSchema,patientSchema} from "@/lib/clinic";
import {listPatients,resolvePatient,patientStatements} from "@/lib/patient-db";
import {workspace} from "@/app/api/records/route";
export async function POST(req:Request){
 try {
  const payload:any=await req.json(),w=await workspace();
  let parsed;
  if(payload.firstName===undefined){
   const contact=contactSchema.parse(payload);
   const existing=(await listPatients(w)).find(r=>r.patientId===payload.patientId);
   if(!existing)return Response.json({error:"Choose an existing demo patient."},{status:404});
   if(contact.dob!==existing.dob)return Response.json({error:"Birthdate must match the selected patient."},{status:400});
   parsed=patientSchema.safeParse({...existing,firstName:existing.firstName||existing.name.split(" ")[0],lastName:existing.lastName||existing.name.split(" ").slice(1).join(" "),...contact});
  }else parsed=patientSchema.safeParse(payload);
  if(!parsed.success)return Response.json({error:parsed.error.issues.map(issue=>`${issue.path.join(" ")}: ${issue.message}`).join("; ")},{status:400});
  const data=parsed.data,name=data.firstName+" "+data.lastName;
  const patientId=await resolvePatient(w,name,data.dob,payload.patientId);
  const patient={...data,name,patientId};
  await db().batch(patientStatements(w,patient));
  return Response.json({ok:true,patientId,patient},{status:201});
 }catch(e){console.error(e);return Response.json({error:String(e).includes("PATIENT_MISMATCH")?"The name and birthdate must match the selected patient.":"Patient could not be saved. Your form is still available; please retry."},{status:String(e).includes("PATIENT_MISMATCH")?400:503});}
}
